# Jewelry Store — Full-stack Starter (Direct Cloudinary Uploads)

This contains a starter full e-commerce application for selling jewelry with direct signed Cloudinary uploads.

## How to run locally (short)
1. Start MongoDB Atlas and copy your connection URI to `backend/.env` (use `.env.example` as template).
2. In one terminal:
   ```
   cd backend
   npm install
   npm run seed
   npm run dev
   ```
3. In another terminal:
   ```
   cd frontend
   npm install
   npm run dev
   ```
4. Open `http://localhost:5173` (or Vite's port) and backend on `http://localhost:5000`

## Cloudinary signed uploads
- POST /api/cloudinary/sign  -> returns { signature, timestamp, api_key, cloud_name }
- The frontend then uploads directly to Cloudinary using the returned signature and timestamp.
