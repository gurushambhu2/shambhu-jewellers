require('dotenv').config()
const mongoose = require('mongoose')
const Product = require('../models/Product')

const items = [
  { name: 'Classic Solitaire Diamond Ring', description: '18K white gold solitaire with brilliant cut diamond.', price: 120000, images: ['/assets/ring1.jpg'], category: 'Rings', stock: 5, sku: 'RNG-001' },
  { name: 'Rose Gold Heart Pendant', description: '14K rose gold pendant with cubic zirconia accents.', price: 4500, images: ['/assets/pendant1.jpg'], category: 'Necklaces', stock: 20, sku: 'PND-001' },
  { name: 'Pearl Drop Earrings', description: 'Freshwater pearls with sterling silver hooks.', price: 3500, images: ['/assets/earring1.jpg'], category: 'Earrings', stock: 15, sku: 'ER-001' },
  { name: "Men's Signet Ring", description: 'Solid gold signet with polished finish.', price: 25000, images: ['/assets/ring2.jpg'], category: 'Rings', stock: 4, sku: 'RNG-002' },
  { name: 'Cubic Zirconia Tennis Bracelet', description: 'Classic tennis bracelet with secure clasp.', price: 8000, images: ['/assets/bracelet1.jpg'], category: 'Bracelets', stock: 10, sku: 'BR-001' },
  { name: 'Emerald Halo Earrings', description: 'Emerald center stones with diamond halo.', price: 22000, images: ['/assets/earring2.jpg'], category: 'Earrings', stock: 6, sku: 'ER-002' },
  { name: 'Layered Chain Necklace', description: 'Triple-layered gold-plated chain, adjustable length.', price: 3000, images: ['/assets/necklace1.jpg'], category: 'Necklaces', stock: 25, sku: 'PND-002' },
  { name: 'Antique Filigree Brooch', description: 'Intricate filigree work inspired by vintage designs.', price: 6000, images: ['/assets/brooch1.jpg'], category: 'Brooches', stock: 8, sku: 'BR-002' },
  { name: 'Sapphire Cocktail Ring', description: 'Blue sapphire with pavé diamonds.', price: 45000, images: ['/assets/ring3.jpg'], category: 'Rings', stock: 3, sku: 'RNG-003' },
  { name: 'Gold Hoop Earrings - Small', description: 'Everyday 14K gold hoops.', price: 9000, images: ['/assets/earring3.jpg'], category: 'Earrings', stock: 30, sku: 'ER-003' },
  { name: 'Custom Engraved Locket', description: 'Openable locket with engraving option.', price: 7000, images: ['/assets/pendant2.jpg'], category: 'Necklaces', stock: 12, sku: 'PND-003' },
  { name: 'Beaded Gemstone Bracelet', description: 'Multi-gemstone beads with elastic band.', price: 2800, images: ['/assets/bracelet2.jpg'], category: 'Bracelets', stock: 18, sku: 'BR-003' }
]

async function seed(){
  await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  console.log('connected, seeding...')
  await Product.deleteMany({})
  await Product.insertMany(items)
  console.log('seeded', items.length, 'items')
  process.exit(0)
}

seed().catch(console.error)
