# Backend — Jewelry Store (Signed Cloudinary Uploads)

## Quick start
1. Copy `.env.example` to `.env` and fill `MONGO_URI`, Cloudinary keys and payment keys.
2. `cd backend`
3. `npm install`
4. `npm run seed`  # to import seed data (requires MONGO_URI)
5. `npm run dev`   # or `npm start`

## Cloudinary signed uploads
- POST /api/cloudinary/sign  -> returns { signature, timestamp, api_key, cloud_name }
- The frontend uses this to upload directly to Cloudinary without sending file bytes through your server.
