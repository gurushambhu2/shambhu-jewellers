const express = require('express')
const router = express.Router()
const crypto = require('crypto')

// Endpoint: POST /api/cloudinary/sign
// Returns: { signature, timestamp, api_key, cloud_name }
router.post('/sign', (req, res) => {
  const timestamp = Math.round((new Date()).getTime() / 1000)
  // You can include folder or other params in the signature if you want to lock uploads
  const params_to_sign = `timestamp=${timestamp}`
  const api_secret = process.env.CLOUDINARY_API_SECRET || 'your_api_secret_here'
  const signature = crypto.createHash('sha1').update(params_to_sign + api_secret).digest('hex')
  res.json({
    signature,
    timestamp,
    api_key: process.env.CLOUDINARY_API_KEY || 'your_api_key_here',
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME || 'shambhujewellers'
  })
})

module.exports = router
