const express = require('express')
const router = express.Router()
const jwt = require('jsonwebtoken')

const ADMIN_USER = {
  username: 'admin',
  password: 'admin123'
}

router.post('/login', (req, res) => {
  const { username, password } = req.body
  if (username === ADMIN_USER.username && password === ADMIN_USER.password) {
    const token = jwt.sign({ username }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '7d' })
    return res.json({ token })
  }
  res.status(401).json({ message: 'Invalid credentials' })
})

function auth(req, res, next){
  const authHeader = req.headers.authorization
  if (!authHeader) return res.status(401).json({ message: 'Missing token' })
  const token = authHeader.split(' ')[1]
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret')
    req.user = payload
    next()
  } catch (err) {
    return res.status(401).json({ message: 'Invalid token' })
  }
}

router.get('/me', auth, (req, res) => {
  res.json({ user: req.user })
})

module.exports = router
