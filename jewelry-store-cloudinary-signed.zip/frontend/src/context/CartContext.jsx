import React, { createContext, useContext, useReducer } from 'react'

const State = createContext()
const Dispatch = createContext()

function reducer(state, action){
  switch(action.type){
    case 'ADD':
      const existing = state.items.find(i=>i._id===action.item._id)
      if (existing) {
        return { ...state, items: state.items.map(i=> i._id===action.item._id ? { ...i, quantity: i.quantity+action.item.quantity } : i) }
      }
      return { ...state, items: [...state.items, action.item] }
    case 'REMOVE':
      return { ...state, items: state.items.filter(i=> i._id !== action.id) }
    case 'CLEAR':
      return { ...state, items: [] }
    default:
      return state
  }
}

export function CartProvider({ children }){
  const [state, dispatch] = useReducer(reducer, { items: [] })
  return <State.Provider value={state}><Dispatch.Provider value={dispatch}>{children}</Dispatch.Provider></State.Provider>
}

export const useCart = () => [ useContext(State), useContext(Dispatch) ]
