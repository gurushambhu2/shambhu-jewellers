import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import AdminProducts from './AdminProducts'
import AdminLogin from './AdminLogin'

export default function AdminDashboard(){
  return (
    <div>
      <h2>Admin</h2>
      <nav>
        <Link to="login">Login</Link> | <Link to="products">Products</Link>
      </nav>
      <div style={{marginTop:12}}>
        <Routes>
          <Route path="login" element={<AdminLogin />} />
          <Route path="products" element={<AdminProducts />} />
        </Routes>
      </div>
    </div>
  )
}
