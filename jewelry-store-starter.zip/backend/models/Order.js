const mongoose = require('mongoose')
const orderSchema = new mongoose.Schema({
  items: [{ 
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' }, 
    name: String,
    price: Number,
    quantity: Number
  }],
  amount: Number,
  currency: { type: String, default: 'INR' },
  billing: {
    name: String,
    email: String,
    phone: String,
    address: String
  },
  payment: {
    provider: String, // 'razorpay' or 'stripe'
    status: String,
    meta: Object
  },
  createdAt: { type: Date, default: Date.now }
})
module.exports = mongoose.model('Order', orderSchema)
