const express = require('express')
const router = express.Router()
const Order = require('../models/Order')
const Razorpay = require('razorpay')
const stripe = require('stripe')(process.env.STRIPE_SECRET || '')

// Create Razorpay instance if keys present
let razor = null
if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
  razor = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET })
}

// POST /api/orders/create (create order and payment order)
router.post('/create', async (req, res) => {
  // expected: { items, billing, currency, paymentProvider } 
  const { items, billing, currency='INR', paymentProvider='razorpay' } = req.body
  const amount = items.reduce((s, it) => s + (it.price * it.quantity), 0)
  const order = new Order({ items, billing, amount, currency, payment: { provider: paymentProvider, status: 'pending' } })
  await order.save()

  // Razorpay flow: create order
  if (paymentProvider === 'razorpay' && razor) {
    const rOrder = await razor.orders.create({
      amount: Math.round(amount * 100), // paise
      currency,
      receipt: order._id.toString()
    })
    return res.json({ orderId: order._id, razorpay: rOrder })
  }

  // Stripe flow: create PaymentIntent
  if (paymentProvider === 'stripe' && process.env.STRIPE_SECRET) {
    const pi = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency: currency.toLowerCase(),
      metadata: { orderId: order._id.toString() }
    })
    return res.json({ orderId: order._id, stripe: { clientSecret: pi.client_secret } })
  }

  // fallback
  res.json({ orderId: order._id })
})

// POST /api/orders/webhook/razorpay  (verify signature and update order)
// Note: Razorpay webhook payloads must be configured in Razorpay dashboard.
router.post('/webhook/razorpay', express.raw({ type: 'application/json' }), async (req, res) => {
  const secret = process.env.RAZORPAY_KEY_SECRET || ''
  const signature = req.headers['x-razorpay-signature']
  const body = req.body
  const crypto = require('crypto')
  const hmac = crypto.createHmac('sha256', secret).update(body).digest('hex')
  if (hmac === signature) {
    // parse JSON
    const payload = JSON.parse(body.toString())
    // handle payment captured events
    if (payload.event === 'payment.captured') {
      const receipt = payload.payload.payment.entity.receipt
      const order = await Order.findById(receipt)
      if (order) {
        order.payment.status = 'captured'
        order.payment.meta = payload
        await order.save()
      }
    }
    return res.status(200).send('ok')
  }
  res.status(400).send('invalid signature')
})

// POST /api/orders/webhook/stripe  (stripe webhook handling)
router.post('/webhook/stripe', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature']
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || ''
  let event = null
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret)
  } catch (err) {
    console.error('Stripe webhook error', err)
    return res.status(400).send(`Webhook Error: ${err.message}`)
  }
  // Handle payment_intent.succeeded
  if (event.type === 'payment_intent.succeeded') {
    const pi = event.data.object
    // in a full app, find the order by metadata.orderId and mark paid
    console.log('PaymentIntent succeeded for', pi.metadata)
  }
  res.json({ received: true })
})

// Create a simple listing endpoint
router.get('/', async (req, res) => {
  const orders = await Order.find({}).limit(50)
  res.json(orders)
})

module.exports = router
