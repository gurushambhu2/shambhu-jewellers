# Backend — Jewelry Store Starter

## Quick start
1. Copy `.env.example` to `.env` and fill `MONGO_URI` and any payment keys.
2. `cd backend`
3. `npm install`
4. `npm run seed`  # to import seed data (requires MONGO_URI)
5. `npm run dev`   # or `npm start`

## Payment support
- Razorpay: uses `razorpay` package. Configure `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`.
- Stripe: set `STRIPE_SECRET` and `STRIPE_WEBHOOK_SECRET`. Stripe webhook endpoint is `/api/orders/webhook/stripe`.

Notes: This starter includes basic webhook verification examples. For production, secure endpoints, use HTTPS, CSRF protections, stronger auth, rate-limiting, and validation.
