# Jewelry Store — Full-stack Starter

This repository contains a starter full e-commerce application for selling jewelry:
- Frontend: Vite + React (product listing, cart, checkout, simple admin UI)
- Backend: Node.js + Express + MongoDB (products, orders)
- Payment integration examples: Razorpay (India) and Stripe (global)
- Seed data and import script for MongoDB Atlas

## How to run locally (short)
1. Start MongoDB Atlas and copy your connection URI to `backend/.env` (use `.env.example` as template).
2. In one terminal:
   ```
   cd backend
   npm install
   npm run seed
   npm run dev
   ```
3. In another terminal:
   ```
   cd frontend
   npm install
   npm run dev
   ```
4. Open `http://localhost:5173` (or Vite's port) and backend on `http://localhost:5000`

## Payment notes
- Razorpay: create an account, get key id & secret, configure in backend `.env`. Add webhook endpoint `/api/orders/webhook/razorpay`.
- Stripe: set `STRIPE_SECRET` and `STRIPE_WEBHOOK_SECRET` in `.env`. Webhook endpoint is `/api/orders/webhook/stripe`.

## Admin
- Demo admin login available at `/admin/login`. Default demo credentials are `admin` / `admin123`. This is intentionally minimal.

## What's included
- Full source skeleton and working endpoints for product CRUD, order creation, webhook samples, frontend admin UI, seed data.
