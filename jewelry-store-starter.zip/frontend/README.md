# Frontend — Jewelry Store (Vite + React)

## Quick start
1. `cd frontend`
2. `npm install`
3. `npm run dev`

Environment:
- Create `.env` file with `VITE_API_BASE` if your backend isn't on localhost:5000.

Admin:
- This demo stores a token in localStorage after calling /api/admin/login. The default demo credentials are `admin` / `admin123`. Change on server.
