import React from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import ProductList from './components/ProductList'
import ProductPage from './components/ProductPage'
import CartPage from './components/CartPage'
import Checkout from './components/Checkout'
import AdminDashboard from './admin/AdminDashboard'
import { CartProvider } from './context/CartContext'

export default function App(){
  return (
    <CartProvider>
      <BrowserRouter>
        <header className="site-header">
          <Link to="/"><h1>Jewelry Store</h1></Link>
          <nav>
            <Link to="/cart">Cart</Link> | <Link to="/admin">Admin</Link>
          </nav>
        </header>
        <main className="container">
          <Routes>
            <Route path="/" element={<ProductList />} />
            <Route path="/product/:id" element={<ProductPage />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/admin/*" element={<AdminDashboard />} />
          </Routes>
        </main>
      </BrowserRouter>
    </CartProvider>
  )
}
