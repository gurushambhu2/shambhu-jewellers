import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import API from '../api'
import { useCart } from '../context/CartContext'

export default function ProductPage(){
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [qty, setQty] = useState(1)
  const [, dispatch] = useCart()
  const nav = useNavigate()

  useEffect(()=>{ API.get('/products/'+id).then(r=>setProduct(r.data)).catch(()=>{}) },[id])

  if (!product) return <div>Loading...</div>

  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:20}}>
      <div>
        <img src={product.images && product.images[0] ? product.images[0] : '/placeholder.jpg'} style={{width:'100%', maxHeight:500, objectFit:'cover'}} />
        <h2>{product.name}</h2>
        <p>₹ {product.price}</p>
        <p>{product.description}</p>
      </div>
      <aside className="card">
        <div className="form-row">
          <label>Quantity</label>
          <input type="number" value={qty} min="1" onChange={e=>setQty(Number(e.target.value))} />
        </div>
        <button className="button" onClick={()=>{
          dispatch({ type:'ADD', item: { ...product, quantity: qty } })
          nav('/cart')
        }}>Add to cart</button>
      </aside>
    </div>
  )
}
