import React, { useState } from 'react'
import { useCart } from '../context/CartContext'
import API from '../api'
import { useNavigate } from 'react-router-dom'

export default function Checkout(){
  const [state, dispatch] = useCart()
  const nav = useNavigate()
  const [billing, setBilling] = useState({ name:'', email:'', phone:'', address:'' })
  const [provider, setProvider] = useState('razorpay') // or 'stripe'
  const total = state.items.reduce((s,i)=> s + (i.price * i.quantity), 0)

  async function placeOrder(e){
    e.preventDefault()
    const payload = { items: state.items, billing, currency: 'INR', paymentProvider: provider }
    const res = await API.post('/orders/create', payload)
    // handle provider response
    if (provider === 'razorpay' && res.data.razorpay) {
      const r = res.data.razorpay
      const options = {
        key: r.key_id || '', // backend won't return key_id; configure in frontend env if needed
        amount: r.amount,
        currency: r.currency,
        name: 'Jewelry Store',
        order_id: r.id,
        handler: function(response){
          alert('Payment completed. Please verify webhook on server.')
          dispatch({ type:'CLEAR' })
          nav('/')
        }
      }
      // open Razorpay checkout (assumes Razorpay script included in index.html if used)
      if (window.Razorpay) new window.Razorpay(options).open()
      else alert('Razorpay script not loaded in this demo. In production include checkout script.')
    } else if (provider === 'stripe' && res.data.stripe) {
      // handle stripe client secret
      alert('Stripe client secret received. Integrate Stripe.js on frontend to confirm payment.')
    } else {
      alert('Order created. No payment provider configured on server.')
    }
  }

  return (
    <div>
      <h2>Checkout</h2>
      <form onSubmit={placeOrder}>
        <div className="form-row"><label>Name</label><input required value={billing.name} onChange={e=>setBilling({...billing, name:e.target.value})} /></div>
        <div className="form-row"><label>Email</label><input required value={billing.email} onChange={e=>setBilling({...billing, email:e.target.value})} /></div>
        <div className="form-row"><label>Phone</label><input value={billing.phone} onChange={e=>setBilling({...billing, phone:e.target.value})} /></div>
        <div className="form-row"><label>Address</label><input value={billing.address} onChange={e=>setBilling({...billing, address:e.target.value})} /></div>
        <div className="form-row"><label>Payment provider</label>
          <select value={provider} onChange={e=>setProvider(e.target.value)}>
            <option value="razorpay">Razorpay</option>
            <option value="stripe">Stripe</option>
          </select>
        </div>
        <h3>Amount: ₹ {total}</h3>
        <button className="button" type="submit">Place order</button>
      </form>
    </div>
  )
}
