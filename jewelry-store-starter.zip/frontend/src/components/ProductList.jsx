import React, { useEffect, useState } from 'react'
import API from '../api'
import { Link } from 'react-router-dom'

export default function ProductList(){
  const [items, setItems] = useState([])
  useEffect(()=>{ API.get('/products').then(r=>setItems(r.data)) },[])
  return (
    <div>
      <h2>Products</h2>
      <div className="grid">
        {items.map(p=>(
          <div className="card" key={p._id}>
            <img src={p.images && p.images[0] ? p.images[0] : '/placeholder.jpg'} alt={p.name} />
            <h3>{p.name}</h3>
            <p>₹ {p.price}</p>
            <Link className="button" to={'/product/'+p._id}>View</Link>
          </div>
        ))}
      </div>
    </div>
  )
}
