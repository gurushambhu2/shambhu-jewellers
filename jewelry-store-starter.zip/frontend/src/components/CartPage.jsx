import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'

export default function CartPage(){
  const [state, dispatch] = useCart()
  const nav = useNavigate()
  const total = state.items.reduce((s,i)=> s + (i.price * i.quantity), 0)
  return (
    <div>
      <h2>Your Cart</h2>
      {state.items.length===0 ? <p>No items — <Link to='/'>shop now</Link></p> : (
        <div>
          <div className="grid">
            {state.items.map(i=>(
              <div className="card" key={i._id}>
                <img src={i.images && i.images[0] ? i.images[0] : '/placeholder.jpg'} alt="" />
                <h4>{i.name}</h4>
                <p>Qty: {i.quantity}</p>
                <p>₹ {i.price * i.quantity}</p>
                <button onClick={()=>dispatch({ type:'REMOVE', id: i._id })}>Remove</button>
              </div>
            ))}
          </div>
          <div style={{marginTop:12}}>
            <h3>Total: ₹ {total}</h3>
            <button className="button" onClick={()=>nav('/checkout')}>Proceed to checkout</button>
          </div>
        </div>
      )}
    </div>
  )
}
