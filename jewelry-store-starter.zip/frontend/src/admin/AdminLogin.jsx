import React, { useState } from 'react'
import API from '../api'

export default function AdminLogin(){
  const [creds, setCreds] = useState({ username:'admin', password:'admin123' })
  const [msg, setMsg] = useState('')
  async function submit(e){
    e.preventDefault()
    try {
      const res = await API.post('/admin/login', creds)
      localStorage.setItem('admin_token', res.data.token)
      setMsg('Logged in — token saved')
    } catch (err) {
      setMsg('Login failed')
    }
  }
  return (
    <div className="admin-panel">
      <h3>Admin Login (demo)</h3>
      <form onSubmit={submit}>
        <div className="form-row"><input value={creds.username} onChange={e=>setCreds({...creds, username:e.target.value})} /></div>
        <div className="form-row"><input type="password" value={creds.password} onChange={e=>setCreds({...creds, password:e.target.value})} /></div>
        <button className="button">Login</button>
      </form>
      <p>{msg}</p>
    </div>
  )
}
