import React, { useEffect, useState } from 'react'
import API from '../api'

function getToken(){ return localStorage.getItem('admin_token') }

export default function AdminProducts(){
  const [items, setItems] = useState([])
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({ name:'', price:0, description:'', images:[], stock:0, category:'' })

  useEffect(()=>{ load() },[])
  function load(){ API.get('/products').then(r=>setItems(r.data)) }

  async function create(){
    const headers = getToken() ? { Authorization: 'Bearer '+getToken() } : {}
    await API.post('/products', form, { headers })
    setForm({ name:'', price:0, description:'', images:[], stock:0, category:'' })
    load()
  }
  async function update(){
    const headers = getToken() ? { Authorization: 'Bearer '+getToken() } : {}
    await API.put('/products/'+editing, form, { headers })
    setEditing(null); load()
  }
  async function remove(id){
    const headers = getToken() ? { Authorization: 'Bearer '+getToken() } : {}
    await API.delete('/products/'+id, { headers })
    load()
  }
  return (
    <div>
      <h3>Products</h3>
      <div style={{display:'flex', gap:20}}>
        <div style={{flex:1}}>
          {items.map(i=>(
            <div key={i._id} className="card" style={{marginBottom:8}}>
              <h4>{i.name}</h4>
              <p>₹{i.price}</p>
              <button onClick={()=>{ setEditing(i._id); setForm({ name:i.name, price:i.price, description:i.description, images:i.images, stock:i.stock, category:i.category }) }}>Edit</button>
              <button onClick={()=>remove(i._id)}>Delete</button>
            </div>
          ))}
        </div>
        <aside style={{width:380}}>
          <div className="admin-panel">
            <h4>{editing ? 'Edit product' : 'Add product'}</h4>
            <div className="form-row"><input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} /></div>
            <div className="form-row"><input placeholder="Price" type="number" value={form.price} onChange={e=>setForm({...form, price:Number(e.target.value)})} /></div>
            <div className="form-row"><input placeholder="Category" value={form.category} onChange={e=>setForm({...form, category:e.target.value})} /></div>
            <div className="form-row"><input placeholder="Image URL (comma separated)" value={(form.images||[]).join(',')} onChange={e=>setForm({...form, images: e.target.value.split(',').map(s=>s.trim())})} /></div>
            <div className="form-row"><textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} /></div>
            <div style={{display:'flex', gap:8}}>
              {editing ? <button className="button" onClick={update}>Update</button> : <button className="button" onClick={create}>Create</button>}
              {editing ? <button onClick={()=>{ setEditing(null); setForm({ name:'', price:0, description:'', images:[], stock:0, category:'' }) }}>Cancel</button> : null}
            </div>
          </div>
        </aside>
      </div>
    </div>
  )
}
