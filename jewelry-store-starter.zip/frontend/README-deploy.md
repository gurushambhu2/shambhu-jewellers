Deploying:
- Build: `npm run build`
- Deploy the `dist` folder to Vercel/Netlify. Set environment `VITE_API_BASE` to your backend URL.
